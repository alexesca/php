<div class="container">
    <header>
        <div class="header">
            <h1>SupportsPro Technical Support</h1>
            <h5>Support management software for the sports enthusiast</h5>
            <a href="" class="btn btn-primary" role="button">Home</a>
            <hr>
        </div>
    </header>
</div>