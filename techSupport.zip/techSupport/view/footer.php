<div class="container">
    <footer>
        <hr>
        <h6>	&copy; SportsPro Inc :)</h6>
    </footer>
</div>