<?php
if($error)
    echo "<h1>{$error}</h1>";
?>