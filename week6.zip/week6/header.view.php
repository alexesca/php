<?php
    echo "<h1>My Guitar Shop</h1> <a href='index.php?action=USERS_LIST_PRODUCTS'>Customer View</a> | <a href='index.php'>Manager View</a>";
    echo "<hr>";
?>