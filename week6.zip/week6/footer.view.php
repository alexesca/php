<?php
    echo "<hr>";
    echo "@2017 My Guitar Shop, Inc.";
?>